# Lab_Managment_System
Laboratory Managment System - MERN Stack

![admin-dash](https://github.com/samithadev/Lab_Managment_System/assets/89331663/362d1fd2-5493-413e-8e2c-ab1706c0ec2d)
![tests-update](https://github.com/samithadev/Lab_Managment_System/assets/89331663/734530e4-1026-4541-9c43-35c8872fb011)
![tests-All](https://github.com/samithadev/Lab_Managment_System/assets/89331663/6d00715b-9b5b-4b02-8b6b-583880316410)
![tests-add](https://github.com/samithadev/Lab_Managment_System/assets/89331663/3c32bd7b-f218-4fb4-a08c-156bb2b3dacf)
![report-view](https://github.com/samithadev/Lab_Managment_System/assets/89331663/ed0dd957-e641-4e51-8cce-f3ebebce0f96)
![report-requests](https://github.com/samithadev/Lab_Managment_System/assets/89331663/7f66c7c8-35dc-4712-b84b-e632317016cd)
![report-form](https://github.com/samithadev/Lab_Managment_System/assets/89331663/e83eb7c9-2d48-4751-acb0-b93bbd99f80d)
![report-down-button](https://github.com/samithadev/Lab_Managment_System/assets/89331663/494534a3-4047-4f80-9f27-46ff64311cf2)
![assis-update](https://github.com/samithadev/Lab_Managment_System/assets/89331663/23d893f1-de59-4185-90df-c6b87fb94bb4)
![assis-all](https://github.com/samithadev/Lab_Managment_System/assets/89331663/c402ba7a-0b76-4899-8e61-47ad48461477)
![assis-add](https://github.com/samithadev/Lab_Managment_System/assets/89331663/c62a39e9-ca5d-4393-ad8b-c2162cf2b9eb)

